PPM 2.1.6 — Python CLI MVP

Quick start:
  export PYTHONPATH=./ppm-cli
  python -m ppm.cli --root . init
  python -m ppm.cli --root . add requests==2.32.3
  python -m ppm.cli --root . sbom --out sbom.json
  python -m ppm.cli --root . lock --export-pylock pylock.toml
